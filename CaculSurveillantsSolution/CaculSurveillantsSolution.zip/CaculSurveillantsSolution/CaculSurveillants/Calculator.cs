﻿public class Calculator
{
    public int CalculNombreSurveillant(int nombreEtudiant)
    {
        throw new NotImplementedException();
    }
}